<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.edit')); ?> <?php echo e(trans('cruds.orderditempat.title_singular')); ?>

    </div>

    <div class="card-body">
        <form method="POST" action="<?php echo e(route("admin.orderditempats.update", [$orderditempat->id])); ?>" enctype="multipart/form-data">
            <?php echo method_field('PUT'); ?>
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="nama_pemesan"><?php echo e(trans('cruds.orderditempat.fields.nama_pemesan')); ?></label>
                <input class="form-control <?php echo e($errors->has('nama_pemesan') ? 'is-invalid' : ''); ?>" type="text" name="nama_pemesan" id="nama_pemesan" value="<?php echo e(old('nama_pemesan', $orderditempat->nama_pemesan)); ?>">
                <?php if($errors->has('nama_pemesan')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('nama_pemesan')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.orderditempat.fields.nama_pemesan_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="products"><?php echo e(trans('cruds.orderditempat.fields.product')); ?></label>
                <div style="padding-bottom: 4px">
                    <span class="btn btn-info btn-xs select-all" style="border-radius: 0"><?php echo e(trans('global.select_all')); ?></span>
                    <span class="btn btn-info btn-xs deselect-all" style="border-radius: 0"><?php echo e(trans('global.deselect_all')); ?></span>
                </div>
                <select class="form-control select2 <?php echo e($errors->has('products') ? 'is-invalid' : ''); ?>" name="products[]" id="products" multiple required>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($product->id); ?>" <?php echo e((in_array($product->id, old('products', [])) || (collect($orderditempat->product_details ?? [])->pluck('id')->contains($product->id))) ? 'selected' : ''); ?>>
                            <?php echo e($product->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('products')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('products')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.orderditempat.fields.product_helper')); ?></span>
            </div>
            <div id="product-quantities">
                <!-- Placeholder for dynamic product quantities -->
            </div>
            <div class="form-group">
                <label for="price"><?php echo e(trans('cruds.orderditempat.fields.price')); ?></label>
                <input class="form-control <?php echo e($errors->has('price') ? 'is-invalid' : ''); ?>" type="number" name="price" id="price" value="<?php echo e(old('price', $orderditempat->price)); ?>" step="0.01">
                <?php if($errors->has('price')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('price')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.orderditempat.fields.price_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="table_id"><?php echo e(trans('cruds.orderditempat.fields.table')); ?></label>
                <select class="form-control select2 <?php echo e($errors->has('table') ? 'is-invalid' : ''); ?>" name="table_id" id="table_id" required>
                    <option value disabled <?php echo e(old('table_id', null) === null ? 'selected' : ''); ?>><?php echo e(trans('global.pleaseSelect')); ?></option>
                    <?php $__currentLoopData = $tables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $table): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e((old('table_id') ? old('table_id') : $orderditempat->table_id ?? '') == $id ? 'selected' : ''); ?>><?php echo e($table); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('table')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('table')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.orderditempat.fields.table_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="jam_pesan"><?php echo e(trans('cruds.orderditempat.fields.jam_pesan')); ?></label>
                <input class="form-control <?php echo e($errors->has('jam_pesan') ? 'is-invalid' : ''); ?>" type="time" name="jam_pesan" id="jam_pesan" value="<?php echo e(old('jam_pesan', $orderditempat->jam_pesan)); ?>" required>
                <?php if($errors->has('jam_pesan')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('jam_pesan')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.orderditempat.fields.jam_pesan_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="tanggal_pesan"><?php echo e(trans('cruds.orderditempat.fields.tanggal_pesan')); ?></label>
                <input class="form-control <?php echo e($errors->has('tanggal_pesan') ? 'is-invalid' : ''); ?>" type="date" name="tanggal_pesan" id="tanggal_pesan" value="<?php echo e(old('tanggal_pesan', $orderditempat->tanggal_pesan)); ?>" required>
                <?php if($errors->has('tanggal_pesan')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('tanggal_pesan')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.orderditempat.fields.tanggal_pesan_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="status_bayar"><?php echo e(trans('cruds.orderditempat.fields.status_bayar')); ?></label>
                <select class="form-control <?php echo e($errors->has('status_bayar') ? 'is-invalid' : ''); ?>" name="status_bayar" id="status_bayar" required>
                    <option value disabled <?php echo e(old('status_bayar', null) === null ? 'selected' : ''); ?>><?php echo e(trans('global.pleaseSelect')); ?></option>
                    <?php $__currentLoopData = App\Models\OrderDitempat::STATUS_SELECT; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>" <?php echo e(old('status_bayar', $orderditempat->status_bayar) == $key ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('status_bayar')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('status_bayar')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.orderditempat.fields.status_bayar_helper')); ?></span>
            </div>
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    <?php echo e(trans('global.save')); ?>

                </button>
            </div>
        </form>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
//     Dropzone.options.imageDropzone = {
//     url: '<?php echo e(route('admin.orderditempats.storeMedia')); ?>',
//     maxFilesize: 2, // MB
//     acceptedFiles: '.jpeg,.jpg,.png,.gif',
//     maxFiles: 1,
//     addRemoveLinks: true,
//     headers: {
//       'X-CSRF-TOKEN': "<?php echo e(csrf_token()); ?>"
//     },
//     params: {
//       size: 2,
//       width: 4096,
//       height: 4096
//     },
//     success: function (file, response) {
//       $('form').find('input[name="image"]').remove()
//       $('form').append('<input type="hidden" name="image" value="' + response.name + '">')
//     },
//     removedfile: function (file) {
//       file.previewElement.remove()
//       if (file.status !== 'error') {
//         $('form').find('input[name="image"]').remove()
//         this.options.maxFiles = this.options.maxFiles + 1
//       }
//     },
//     init: function () {
// <?php if(isset($orderditempat) && $orderditempat->image): ?>
//       var file = <?php echo json_encode($orderditempat->image); ?>

//           this.options.addedfile.call(this, file)
//       this.options.thumbnail.call(this, file, file.preview ?? file.preview_url)
//       file.previewElement.classList.add('dz-complete')
//       $('form').append('<input type="hidden" name="image" value="' + file.file_name + '">')
//       this.options.maxFiles = this.options.maxFiles - 1
// <?php endif; ?>
//     },
//     error: function (file, response) {
//         if ($.type(response) === 'string') {
//             var message = response //dropzone sends it's own error messages in string
//         } else {
//             var message = response.errors.file
//         }
//         file.previewElement.classList.add('dz-error')
//         _ref = file.previewElement.querySelectorAll('[data-dz-errormessage]')
//         _results = []
//         for (_i = 0, _len = _ref.length; _i < _len; _i++) {
//             node = _ref[_i]
//             _results.push(node.textContent = message)
//         }

//         return _results
//     }
// }

$(document).ready(function() {
    const productPrices = <?php echo json_encode($productPrices, 15, 512) ?>;
    const oldQuantities = <?php echo json_encode(old('product_qty', $orderditempat->product_details->pluck('qty', 'id')->toArray())) ?>;

    function updateProductQuantities() {
        let selectedProducts = $('#products').val();
        let productQuantitiesContainer = $('#product-quantities');
        productQuantitiesContainer.empty();

        selectedProducts.forEach(function(productId, index) {
            let productLabel = $('#products option[value="'+productId+'"]').text();
            let productPrice = productPrices[productId];
            let oldQuantity = oldQuantities[productId] || 1; // Default value to 1 if old quantity not available
            productQuantitiesContainer.append(`
                <div class="form-group">
                    <label for="qty_${productId}">${productLabel} <?php echo e(trans('cruds.orderditempat.fields.qty')); ?></label>
                    <input class="form-control product-qty" data-product-id="${productId}" type="number" name="product_qty[${productId}]" id="qty_${productId}" value="${oldQuantity}">
                    <input type="hidden" class="product-price" data-product-id="${productId}" value="${productPrice}">
                </div>
            `);
        });

        updateTotalPrice();
    }

    function updateTotalPrice() {
        let totalPrice = 0;
        $('.product-qty').each(function() {
            let productId = $(this).data('product-id');
            let quantity = parseFloat($(this).val());
            let price = parseFloat($('.product-price[data-product-id="'+productId+'"]').val());
            totalPrice += quantity * price;
        });
        $('#price').val(totalPrice.toFixed(2));
    }

    $('#products').change(function() {
        updateProductQuantities();
    });

    $('#product-quantities').on('input', '.product-qty', function() {
        updateTotalPrice();
    });

    updateProductQuantities();
});

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/orderditempats/edit.blade.php ENDPATH**/ ?>