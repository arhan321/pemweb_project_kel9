<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.show')); ?> <?php echo e(trans('cruds.whys.title')); ?>

    </div>

    <div class="card-body">
        <div class="form-group">
            <div class="form-group">
                <a class="btn btn-default" href="<?php echo e(route('admin.whys.index')); ?>">
                    <?php echo e(trans('globalwhyso_list')); ?>

                </a>
            </div>
            <table class="table table-bordered table-striped">
                <tbody>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.whys.fields.id')); ?>

                        </th>
                        <td>
                            <?php echo e($why->id); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.whys.fields.title_1')); ?>

                        </th>
                        <td>
                            <?php echo e($why->title_1); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.whys.fields.title_2')); ?>

                        </th>
                        <td>
                            <?php echo e($why->title_2); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.whys.fields.nomor_box')); ?>

                        </th>
                        <td>
                            <?php echo e($why->nomor_box); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.whys.fields.description_box_1')); ?>

                        </th>
                        <td>
                            <?php echo $why->description_box_1; ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.whys.fields.description_box_2')); ?>

                        </th>
                        <td>
                            <?php echo $why->description_box_2; ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.whys.fields.image')); ?>

                        </th>
                        <td>
                            <?php if($why->image): ?>
                                <a href="<?php echo e($why->image->getUrl()); ?>" target="_blank" style="display: inline-block">
                                    <img src="<?php echo e($why->image->getUrl('thumb')); ?>">
                                </a>
                            <?php endif; ?>
                        </td>
                    </tr>
                </tbody>
            </table>
            <div class="form-group">
                <a class="btn btn-default" href="<?php echo e(route('admin.whys.index')); ?>">
                    <?php echo e(trans('global.back_to_list')); ?>

                </a>
            </div>
        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/whys/show.blade.php ENDPATH**/ ?>