<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.show')); ?> <?php echo e(trans('cruds.orderditempat.title')); ?>

    </div>

    <div class="card-body">
        <div class="form-group">
            <div class="form-group">
                <a class="btn btn-default" href="<?php echo e(route('admin.orderditempats.index')); ?>">
                    <?php echo e(trans('global.back_to_list')); ?>

                </a>
            </div>
            <table class="table table-bordered table-striped">
                <tbody>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.orderditempat.fields.id')); ?>

                        </th>
                        <td>
                            <?php echo e($orderditempat->id); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.orderditempat.fields.nama_pemesan')); ?>

                        </th>
                        <td>
                            <?php echo e($orderditempat->nama_pemesan); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.orderditempat.fields.product')); ?>

                        </th>
                        <td>
                            <?php if(isset($orderditempat->product_details) && count($orderditempat->product_details) > 0): ?>
                                <?php
                                    $productDetails = [];
                                    foreach ($orderditempat->product_details as $product) {
                                        $productDetails[] = $product['name'] . ' (Qty: ' . $product['qty'] . ')';
                                    }
                                    echo implode(', ', $productDetails);
                                ?>
                            <?php else: ?>
                                <div>No product details available</div>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.orderditempat.fields.price')); ?>

                        </th>
                        <td>
                            <?php echo e('Rp ' . number_format($orderditempat->price ?? 0, 2, ',', '.')); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.orderditempat.fields.jam_pesan')); ?>

                        </th>
                        <td>
                            <?php echo e($orderditempat->jam_pesan); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.orderditempat.fields.tanggal_pesan')); ?>

                        </th>
                        <td>
                            <?php echo e($orderditempat->tanggal_pesan); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.orderditempat.fields.table')); ?>

                        </th>
                        <td>
                          <?php echo e(trans('cruds.table_information.table')); ?>  <?php echo e($orderditempat->table_id ?? ''); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.orderditempat.fields.status_bayar')); ?>

                        </th>
                        <td>
                            <?php if($orderditempat->status_bayar == 'Belum bayar'): ?>
                                <span class="status-unpaid"><?php echo e(App\Models\Orderditempat::STATUS_SELECT['Belum bayar'] ?? 'Belum bayar'); ?></span>
                            <?php elseif($orderditempat->status_bayar == 'Sudah bayar'): ?>
                                <span class="status-selesai"><?php echo e(App\Models\Orderditempat::STATUS_SELECT['Sudah bayar'] ?? 'Sudah bayar'); ?></span>
                            <?php else: ?>
                                <?php echo e($orderditempat->status_bayar); ?>

                            <?php endif; ?>
                        </td>
                    </tr>
                </tbody>
            </table>
            <div class="form-group">
                <a class="btn btn-default" href="<?php echo e(route('admin.orderditempats.index')); ?>">
                    <?php echo e(trans('global.back_to_list')); ?>

                </a>
            </div>
        </div>
    </div>
</div>

<style>
    .status-unpaid {
        background-color: red;
        color: white;
        padding: 5px 10px;
        border-radius: 5px;
        font-weight: bold;
        margin: 5px;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        transition: background-color 0.3s, box-shadow 0.3s;
        display: inline-block;
    }

    .status-unpaid:hover {
        background-color: darkred;
        box-shadow: 0 6px 8px rgba(0, 0, 0, 0.2);
    }

    .status-selesai {
        background-color: green;
        color: white;
        padding: 5px 10px;
        border-radius: 5px;
        font-weight: bold;
        margin: 5px;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        transition: background-color 0.3s, box-shadow 0.3s;
        display: inline-block;
    }

    .status-selesai:hover {
        background-color: darkgreen;
        box-shadow: 0 6px 8px rgba(0, 0, 0, 0.2);
    }
</style>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/orderditempats/show.blade.php ENDPATH**/ ?>