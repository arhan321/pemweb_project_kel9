<?php $__env->startSection('content'); ?>
<div class="card">
  <div class="card-header">
    <?php echo e(trans('cruds.history_orderditempat.title_singular')); ?> <?php echo e(trans('global.list')); ?>

  </div>

  <div class="card-body">
    <div class="table-responsive">
      <table class=" table table-bordered table-striped table-hover datatable datatable-history_order_reservation">
        <thead>
          <tr>
            <th width="10"></th>
            <th><?php echo e(trans('cruds.history_orderditempat.fields.id')); ?></th>
            <th><?php echo e(trans('cruds.history_orderditempat.fields.nama_pemesan')); ?></th>
            <th><?php echo e(trans('cruds.history_orderditempat.fields.product')); ?></th>
            <th><?php echo e(trans('cruds.history_orderditempat.fields.price')); ?></th>
            <th><?php echo e(trans('cruds.history_orderditempat.fields.jam_pesan')); ?></th>
            <th><?php echo e(trans('cruds.history_orderditempat.fields.tanggal_pesan')); ?></th>
            <th><?php echo e(trans('cruds.history_orderditempat.fields.table')); ?></th>
            <th><?php echo e(trans('cruds.history_orderditempat.fields.status_bayar')); ?></th>
            <th>&nbsp;</th>
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $orderditempats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr data-entry-id="<?php echo e($h->id); ?>">
            <td></td>
            <td><?php echo e($h->id ?? ''); ?></td>
            <td><?php echo e($h->nama_pemesan ?? ''); ?></td>
            <td>
                <?php if(isset($h->product_details)): ?>
                    <?php
                        $productDetails = [];
                        foreach ($h->product_details as $product) {
                            $productDetails[] = $product['name'] . ' (Qty: ' . $product['qty'] . ')';
                        }
                        echo implode(', ', $productDetails);
                    ?>
                <?php endif; ?>
            </td>
            <td class="price-column">
                <?php echo e('Rp ' . number_format($h->price ?? 0, 2, ',', '.')); ?>

            </td>
            <td><?php echo e($h->jam_pesan ?? ''); ?></td>
            <td><?php echo e($h->tanggal_pesan ?? ''); ?></td>
            <td><?php echo e(trans('cruds.table_information.table')); ?> <?php echo e($h->table_id ?? ''); ?></td>
            <td>
                <?php if($h->status_bayar == 'Belum bayar'): ?>
                    <span class="status-unpaid"><?php echo e(App\Models\OrderDitempat::STATUS_SELECT['Belum_bayar'] ?? 'Belum bayar'); ?></span>
                <?php elseif($h->status_bayar == 'Sudah bayar'): ?>
                    <span class="status-selesai"><?php echo e(App\Models\OrderDitempat::STATUS_SELECT['Sudah_bayar'] ?? 'Sudah bayar'); ?></span>
                <?php else: ?>
                    <?php echo e(App\Models\Booking::STATUS_SELECT[$h->status_bayar] ?? ''); ?>

                <?php endif; ?>
            </td>
            <td></td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<style>
    
  .status-unpaid {
      background-color: red;
      color: white;
      padding: 5px 10px;
      border-radius: 5px;
      font-weight: bold;
      margin: 5px;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
      transition: background-color 0.3s, box-shadow 0.3s;
      display: inline-block;
  }

  .status-unpaid:hover {
      background-color: darkred;
      box-shadow: 0 6px 8px rgba(0, 0, 0, 0.2);
  }

  .status-selesai {
      background-color: green;
      color: white;
      padding: 5px 10px;
      border-radius: 5px;
      font-weight: bold;
      margin: 5px;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
      transition: background-color 0.3s, box-shadow 0.3s;
      display: inline-block;
  }

  .status-selesai:hover {
      background-color: darkgreen;
      box-shadow: 0 6px 8px rgba(0, 0, 0, 0.2);
  }
</style>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<?php echo \Illuminate\View\Factory::parentPlaceholder('scripts'); ?>
<script>
    $(function () {
        let dtButtons = $.extend(true, [], $.fn.dataTable.defaults.buttons);
        $.extend(true, $.fn.dataTable.defaults, {
            orderCellsTop: true,
            order: [[1, 'desc']],
            pageLength: 100,
        });
        let table = $('.datatable-history_order_reservation:not(.ajaxTable)').DataTable({ buttons: dtButtons });
        $('a[data-toggle="tab"]').on('shown.bs.tab click', function(e){
            $($.fn.dataTable.tables(true)).DataTable()
                .columns.adjust();
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/history_orderditempats/index.blade.php ENDPATH**/ ?>