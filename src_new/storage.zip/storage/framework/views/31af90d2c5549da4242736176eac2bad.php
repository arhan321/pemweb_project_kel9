<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.edit')); ?> <?php echo e(trans('cruds.footer.title_singular')); ?>

    </div>

    <div class="card-body">
        <form method="POST" action="<?php echo e(route("admin.footers.update", [$footer->id])); ?>" enctype="multipart/form-data">
            <?php echo method_field('PUT'); ?>
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="logo_restoran"><?php echo e(trans('cruds.footer.fields.logo')); ?></label>
                <input class="form-control <?php echo e($errors->has('logo_restoran') ? 'is-invalid' : ''); ?>" type="text" name="logo_restoran" id="logo_restoran" value="<?php echo e(old('logo_restoran', $footer->logo_restoran)); ?>">
                <?php if($errors->has('logo_restoran')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('logo_restoran')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.footer.fields.logo_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="detail"><?php echo e(trans('cruds.footer.fields.detail')); ?></label>
                <input class="form-control <?php echo e($errors->has('detail') ? 'is-invalid' : ''); ?>" type="text" name="detail" id="detail" value="<?php echo e(old('detail', $footer->detail)); ?>">
                <?php if($errors->has('detail')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('detail')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.footer.fields.detail_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="alamat"><?php echo e(trans('cruds.footer.fields.alamat')); ?></label>
                <textarea class="form-control <?php echo e($errors->has('alamat') ? 'is-invalid' : ''); ?>" name="alamat" id="alamat"><?php echo e(old('alamat', $footer->alamat)); ?></textarea>
                <?php if($errors->has('alamat')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('alamat')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.footer.fields.alamat_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="phone"><?php echo e(trans('cruds.footer.fields.phone')); ?></label>
                <input class="form-control <?php echo e($errors->has('phone') ? 'is-invalid' : ''); ?>" type="text" name="phone" id="phone" value="<?php echo e(old('phone', $footer->phone)); ?>">
                <?php if($errors->has('phone')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('phone')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.footer.fields.phone_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="faximile"><?php echo e(trans('cruds.footer.fields.faximile')); ?></label>
                <input class="form-control <?php echo e($errors->has('faximile') ? 'is-invalid' : ''); ?>" type="text" name="faximile" id="faximile" value="<?php echo e(old('faximile', $footer->faximile)); ?>">
                <?php if($errors->has('faximile')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('faximile')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.footer.fields.faximile_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="faximile"><?php echo e(trans('cruds.footer.fields.faximile')); ?></label>
                <input class="form-control <?php echo e($errors->has('faximile') ? 'is-invalid' : ''); ?>" type="text" name="faximile" id="faximile" value="<?php echo e(old('faximile', $footer->faximile)); ?>">
                <?php if($errors->has('faximile')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('faximile')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.footer.fields.faximile_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="opening_day"><?php echo e(trans('cruds.footer.fields.opening_day')); ?></label>
                <input class="form-control <?php echo e($errors->has('opening_day') ? 'is-invalid' : ''); ?>" type="text" name="opening_day" id="opening_day" value="<?php echo e(old('opening_day', $footer->opening_day)); ?>">
                <?php if($errors->has('opening_day')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('opening_day')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.footer.fields.opening_day_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="opening_hours"><?php echo e(trans('cruds.footer.fields.opening_hours')); ?></label>
                <input class="form-control <?php echo e($errors->has('opening_hours') ? 'is-invalid' : ''); ?>" type="time" name="opening_hours" id="opening_hours" value="<?php echo e(old('opening_hours', $footer->opening_hours)); ?>">
                <?php if($errors->has('opening_hours')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('opening_hours')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.footer.fields.opening_hours_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="closing_hours"><?php echo e(trans('cruds.footer.fields.closing_hours')); ?></label>
                <input class="form-control <?php echo e($errors->has('closing_hours') ? 'is-invalid' : ''); ?>" type="time" name="closing_hours" id="closing_hours" value="<?php echo e(old('closing_hours', $footer->closing_hours)); ?>">
                <?php if($errors->has('closing_hours')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('closing_hours')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.footer.fields.closing_hours_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="copyright"><?php echo e(trans('cruds.footer.fields.copyright')); ?></label>
                <input class="form-control <?php echo e($errors->has('copyright') ? 'is-invalid' : ''); ?>" type="text" name="copyright" id="copyright" value="<?php echo e(old('copyright', $footer->copyright)); ?>">
                <?php if($errors->has('copyright')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('copyright')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.footer.fields.copyright_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="desain_by"><?php echo e(trans('cruds.footer.fields.desain_by')); ?></label>
                <input class="form-control <?php echo e($errors->has('desain_by') ? 'is-invalid' : ''); ?>" type="text" name="desain_by" id="desain_by" value="<?php echo e(old('desain_by', $footer->desain_by)); ?>">
                <?php if($errors->has('desain_by')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('desain_by')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.footer.fields.email_helper')); ?></span>
            </div>
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    <?php echo e(trans('global.save')); ?>

                </button>
            </div>
        </form>
    </div>
</div>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/footers/edit.blade.php ENDPATH**/ ?>