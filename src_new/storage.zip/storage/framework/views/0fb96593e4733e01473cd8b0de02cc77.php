<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.show')); ?> <?php echo e(trans('cruds.signature.title')); ?>

    </div>

    <div class="card-body">
        <div class="form-group">
            <div class="form-group">
                <a class="btn btn-default" href="<?php echo e(route('admin.signatures.index')); ?>">
                    <?php echo e(trans('global.back_to_list')); ?>

                </a>
            </div>
            <table class="table table-bordered table-striped">
                <tbody>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.signature.fields.id')); ?>

                        </th>
                        <td>
                            <?php echo e($signature->id); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.signature.fields.image')); ?>

                        </th>
                        <td>
                            <?php if($signature->image): ?>
                                <a href="<?php echo e($signature->image->getUrl()); ?>" target="_blank" style="display: inline-block">
                                    <img src="<?php echo e($signature->image->getUrl('thumb')); ?>">
                                </a>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.signature.fields.product')); ?>

                        </th>
                        <td>
                            <?php echo e($signature->product->name ?? ''); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.signature.fields.description')); ?>

                        </th>
                        <td>
                            <?php echo $signature->description; ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.signature.fields.category')); ?>

                        </th>
                        <td>
                            <?php echo e(App\Models\Product::CATEGORY_SELECT[$signature->category] ?? ''); ?>

                        </td>
                    </tr>
                </tbody>
            </table>
            <div class="form-group">
                <a class="btn btn-default" href="<?php echo e(route('admin.signatures.index')); ?>">
                    <?php echo e(trans('global.back_to_list')); ?>

                </a>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/signatures/show.blade.php ENDPATH**/ ?>