<?php $__env->startSection('section'); ?>

<?php $__empty_1 = true; $__currentLoopData = $About; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
  <main id="main">
    <!-- ======= About Section ======= -->
    <section id="about" class="about">
      <div class="container" data-aos="fade-up">
        <div class="row">
          <div class="col-lg-6 order-1 order-lg-2" data-aos="zoom-in" data-aos-delay="100">
            <div class="about-img">
              <?php if($a->getFirstMediaUrl('image', 'priview')): ?>
                <img src="<?php echo e($a->getFirstMediaUrl('image', 'priview')); ?>" alt="<?php echo e($a->title); ?>" />
              <?php else: ?>
                <p><?php echo e(trans('panel.frontend.error.img')); ?></p>
              <?php endif; ?>
            </div>
          </div>
          <div class="col-lg-6 pt-4 pt-lg-0 order-2 order-lg-1 content">
            <?php if(isset($a->title)): ?>
              <h3><?php echo $a->title; ?></h3>
            <?php else: ?>
              <h3><?php echo e(trans('panel.frontend.error.title')); ?></h3>
            <?php endif; ?>

            <?php if(isset($a->description)): ?>
              <p class="fst-italic"><?php echo $a->description; ?></p>
            <?php else: ?>
              <p class="fst-italic">Error: Description not available</p>
            <?php endif; ?>
          </div>
        </div>
      </div>
    </section>
    <!-- End About Section -->  
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
  <main id="main">
    <section id="about" class="about">
      <div class="container" data-aos="fade-up">
        <div class="row">
          <div class="col-lg-12 text-center">
            <h3>Error: No about section available</h3>
          </div>
        </div>
      </div>
    </section>
<?php endif; ?>

<!-- ======= Why Us Section ======= -->
<section id="why-us" class="why-us">
  <div class="container" data-aos="fade-up">
    <?php $__currentLoopData = $whyus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="section-title" style="margin-bottom: -30px;">
      <h2><?php echo $ab->title_1; ?></h2>
      <p><?php echo $ab->title_2; ?></p>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
    <div class="row">
      <?php $__empty_1 = true; $__currentLoopData = $whyus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $abo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="col-lg-4 col-md-4">
          <div class="box" data-aos="zoom-in" data-aos-delay="100">
            <?php if(isset($abo->nomor_box)): ?>
              <span><?php echo $abo->nomor_box; ?></span>
            <?php else: ?>
              <span>Error: Box number not available</span>
            <?php endif; ?>

            <?php if(isset($abo->description_box_1)): ?>
              <h4><?php echo $abo->description_box_1; ?></h4>
            <?php else: ?>
              <h4>Error: Box description 1 not available</h4>
            <?php endif; ?>

            <?php if(isset($abo->description_box_2)): ?>
              <p><?php echo $abo->description_box_2; ?></p>
            <?php else: ?>
              <p>Error: Box description 2 not available</p>
            <?php endif; ?>
          </div>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="col-12">
          <p>Error: No box items available</p>
        </div>
      <?php endif; ?>
    </div>
  </div>
</section>
<!-- End Why Us Section -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/frontend/about.blade.php ENDPATH**/ ?>