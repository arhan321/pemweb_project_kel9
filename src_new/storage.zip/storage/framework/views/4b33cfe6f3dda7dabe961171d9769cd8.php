<?php $__env->startSection('section'); ?>
<!-- ======= Specials Section ======= -->
<section id="signature" class="signature">
    <div class="container" data-aos="fade-up">
        <div class="section-title">
            <h2><?php echo e(trans('panel.frontend.signature.signature_1')); ?></h2>
            <p><?php echo e(trans('panel.frontend.signature.signature_2')); ?></p>
        </div>

        <div class="row" data-aos="fade-up" data-aos-delay="100">
            <div class="col-lg-3">
                <ul class="nav nav-tabs flex-column">
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="nav-item">
                        <a class="nav-link <?php if($loop->first): ?> active show <?php endif; ?>" data-bs-toggle="tab" href="#tab-<?php echo e($index); ?>"><?php echo e($category); ?></a>
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <div class="col-lg-9 mt-4 mt-lg-0">
                <div class="tab-content">
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="tab-pane <?php if($loop->first): ?> active show <?php endif; ?>" id="tab-<?php echo e($index); ?>">
                        <div class="row">
                            <?php $__currentLoopData = $signatures->where('category', $category); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $signature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-lg-8 details order-2 order-lg-1">
                                <h3><?php echo e($signature->product->name); ?></h3>
                                <p class="fst-italic"><?php echo $signature->description; ?></p>
                                <p><?php echo e($signature->additional_description); ?></p>
                            </div>
                            <div class="col-lg-4 text-center order-1 order-lg-2">
                                <img src="<?php echo e($signature->getFirstMediaUrl('image', 'preview')); ?>" class="img-fluid" alt="<?php echo e($signature->name); ?>">
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- End Specials Section -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/frontend/signature.blade.php ENDPATH**/ ?>