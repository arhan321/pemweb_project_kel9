<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.create')); ?> <?php echo e(trans('cruds.booking.title_singular')); ?>

    </div>

    <div class="card-body">
        <form method="POST" action="<?php echo e(route("admin.bookings.store")); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label class="required" for="nama_customer"><?php echo e(trans('cruds.booking.fields.nama_customer')); ?></label>
                <input class="form-control <?php echo e($errors->has('nama_customer') ? 'is-invalid' : ''); ?>" type="text" name="nama_customer" id="nama_customer" value="<?php echo e(old('nama_customer', '')); ?>">
                <?php if($errors->has('nama_customer')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('nama_customer')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.booking.fields.title_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="jumlah_orang"><?php echo e(trans('cruds.booking.fields.jumlah_orang')); ?></label>
                <input class="form-control <?php echo e($errors->has('jumlah_orang') ? 'is-invalid' : ''); ?>" type="number" name="jumlah_orang" id="jumlah_orang" value="<?php echo e(old('jumlah_orang', '')); ?>" max="8">
                <?php if($errors->has('jumlah_orang')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('jumlah_orang')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.booking.fields.jumlah_orang_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="booking_date"><?php echo e(trans('cruds.booking.fields.booking_date')); ?></label>
                <input class="form-control date <?php echo e($errors->has('booking_date') ? 'is-invalid' : ''); ?>" type="date" name="booking_date" id="booking_date" value="<?php echo e(old('booking_date')); ?>" required>
                <?php if($errors->has('booking_date')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('booking_date')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.booking.fields.booking_date_helper')); ?></span>
            </div>
            <div class="form-group">
                <input type="hidden" name="start_book" id="start_book" value="<?php echo e(old('start_book')); ?>">
                <input type="hidden" name="finish_book" id="finish_book" value="<?php echo e(old('finish_book')); ?>">
            </div>
            <div class="form-group">
                <label class="required"><?php echo e(trans('cruds.booking.fields.category')); ?></label>
                <select class="form-control <?php echo e($errors->has('category') ? 'is-invalid' : ''); ?>" name="category" id="category" required>
                    <option value disabled <?php echo e(old('category', null) === null ? 'selected' : ''); ?>><?php echo e(trans('global.pleaseSelect')); ?></option>
                    <?php $__currentLoopData = App\Models\Booking::CATEGORY_SELECT; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>" <?php echo e(old('category', '') === (string) $key ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('category')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('category')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.booking.fields.category_helper')); ?></span>
            </div>
         
            <div class="form-group">
                <label class="required" for="table_id"><?php echo e(trans('cruds.booking.fields.table')); ?></label>
                <select class="form-control <?php echo e($errors->has('table_id') ? 'is-invalid' : ''); ?>" name="table_id" id="table_id" required>
                    <option value disabled <?php echo e(old('table_id', null) === null ? 'selected' : ''); ?>><?php echo e(trans('global.pleaseSelect')); ?></option>
                    <?php $__currentLoopData = $availableTables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $table): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($table->id); ?>" data-start="<?php echo e($table->start); ?>" data-finish="<?php echo e($table->finish); ?>" <?php echo e(old('table_id', '') === (string) $table->id ? 'selected' : ''); ?>><?php echo e($table->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('table_id')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('table_id')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.booking.fields.table_helper')); ?></span>
            </div>
            
            <div class="form-group">
                <label class="required" for="customer_email"><?php echo e(trans('cruds.booking.fields.customer_email')); ?></label>
                <input class="form-control <?php echo e($errors->has('customer_email') ? 'is-invalid' : ''); ?>" type="text" name="customer_email" id="customer_email" value="<?php echo e(old('customer_email', '')); ?>">
                <?php if($errors->has('customer_email')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('customer_email')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.booking.fields.customer_email_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="phone"><?php echo e(trans('cruds.booking.fields.phone')); ?></label>
                <input class="form-control <?php echo e($errors->has('phone') ? 'is-invalid' : ''); ?>" type="text" name="phone" id="phone" value="<?php echo e(old('phone', '')); ?>">
                <?php if($errors->has('phone')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('phone')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.booking.fields.phone_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="total_price"><?php echo e(trans('cruds.booking.fields.total_price')); ?></label>
                <input class="form-control <?php echo e($errors->has('total_price') ? 'is-invalid' : ''); ?>" type="number" name="total_price" id="total_price" value="<?php echo e(old('total_price', '')); ?>">
                <?php if($errors->has('total_price')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('total_price')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.booking.fields.total_price_helper')); ?></span>
            </div>
            <div class="form-group">
                <label><?php echo e(trans('cruds.booking.fields.status')); ?></label>
                <select class="form-control <?php echo e($errors->has('status') ? 'is-invalid' : ''); ?>" name="status" id="status">
                    <option value disabled <?php echo e(old('status', null) === null ? 'selected' : ''); ?>><?php echo e(trans('global.pleaseSelect')); ?></option>
                    <?php $__currentLoopData = App\Models\Booking::STATUS_SELECT; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>" <?php echo e(old('status', '') === (string) $key ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('status')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('status')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.booking.fields.status_helper')); ?></span>
            </div>
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    <?php echo e(trans('global.save')); ?>

                </button>
            </div>
        </form>
    </div>
</div>

<script>
document.getElementById('table_id').addEventListener('change', function() {
    var selectedOption = this.options[this.selectedIndex];
    var startBookTime = selectedOption.getAttribute('data-start');
    var finishBookTime = selectedOption.getAttribute('data-finish');
    var bookingDate = document.getElementById('booking_date').value;

    if (bookingDate) {
        document.getElementById('start_book').value = bookingDate + ' ' + startBookTime;
        document.getElementById('finish_book').value = bookingDate + ' ' + finishBookTime;
    } else {
        document.getElementById('start_book').value = '';
        document.getElementById('finish_book').value = '';
    }
});

document.getElementById('booking_date').addEventListener('change', function() {
    var selectedOption = document.getElementById('table_id').options[document.getElementById('table_id').selectedIndex];
    var startBookTime = selectedOption.getAttribute('data-start');
    var finishBookTime = selectedOption.getAttribute('data-finish');
    var bookingDate = this.value;

    if (startBookTime && finishBookTime) {
        document.getElementById('start_book').value = bookingDate + ' ' + startBookTime;
        document.getElementById('finish_book').value = bookingDate + ' ' + finishBookTime;
    }
});
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/bookings/create.blade.php ENDPATH**/ ?>