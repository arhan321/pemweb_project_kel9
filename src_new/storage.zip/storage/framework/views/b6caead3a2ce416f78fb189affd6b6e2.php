<?php $__env->startSection('content'); ?>
<div class="card">
  <div class="card-header">
    <?php echo e(trans('cruds.history_order_reservation.title_singular')); ?> <?php echo e(trans('global.list')); ?>

  </div>

  <div class="card-body">
    <div class="table-responsive">
      <table class=" table table-bordered table-striped table-hover datatable datatable-history_order_reservation">
        <thead>
          <tr>
            <th width="10">

            </th>
            <th>
              <?php echo e(trans('cruds.history_order_reservation.fields.id')); ?>

            </th>
            <th>
              <?php echo e(trans('cruds.history_order_reservation.fields.name')); ?>

            </th>
            <th>
              <?php echo e(trans('cruds.history_order_reservation.fields.days')); ?>

            </th>
            <th>
              <?php echo e(trans('cruds.history_order_reservation.fields.start_time')); ?>

            </th>
            <th>
              <?php echo e(trans('cruds.history_order_reservation.fields.end_time')); ?>

            </th>
            <th>
              <?php echo e(trans('cruds.history_order_reservation.fields.phone')); ?>

            </th>
            <th>
              <?php echo e(trans('cruds.history_order_reservation.fields.email')); ?>

            </th>
            <th>
              <?php echo e(trans('cruds.history_order_reservation.fields.table')); ?>

            </th>
            <th>
              <?php echo e(trans('cruds.history_order_reservation.fields.number_of_people')); ?>

            </th>
            <th>
              <?php echo e(trans('cruds.history_order_reservation.fields.total')); ?>

            </th>
            <th>
              <?php echo e(trans('cruds.history_order_reservation.fields.status')); ?>

            </th>
            <th>
              &nbsp;
            </th>
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr data-entry-id="<?php echo e($p->id); ?>">
            <td>

            </td>
            <td>
              <?php echo e($p->id ?? ''); ?>

            </td>
            <td>
              <?php echo e($p->name ?? ''); ?>

            </td>
            <td>
              <?php echo e($p->days ?? ''); ?>

            </td>
            <td>
              <?php echo e($p->start_time ?? ''); ?>

            </td>
            <td>
              <?php echo e($p->end_time ?? ''); ?>

            </td>
            <td>
              <?php echo e($p->phone ?? ''); ?>

            </td>
            <td>
              <?php echo e($p->customer_email ?? ''); ?>

            </td>
            <td>
              <?php echo e($p->table->name ?? ''); ?>

            </td>
            <td>
              <?php echo e($p->qty ?? ''); ?>

            </td>
            <td>
              Rp <?php echo e(number_format($p->total_price, 2)); ?>

            </td>
            <td>
                <span class="badge <?php if($p->status == 'unpaid'): ?> badge-danger <?php else: ?> badge-success <?php endif; ?>">
                  <?php echo e($p->status ?? ''); ?>

                </span>
              </td>
            <td>
              
            </td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<style>
    .badge {
      padding: 5px 10px;
      border-radius: 4px;
      font-size: 12px;
      text-align: center;
      display: inline-block;
      margin-right: 5px;
    }

    .badge-success {
      background-color: #4CAF50; /* Green */
      color: white;
    }

    .badge-danger {
      background-color: #f44336; /* Red */
      color: white;
    }
  </style>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<?php echo \Illuminate\View\Factory::parentPlaceholder('scripts'); ?>
<script>
    $(function () {
  let dtButtons = $.extend(true, [], $.fn.dataTable.defaults.buttons)
// <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('order_delete')): ?>
//   let deleteButtonTrans = '<?php echo e(trans('global.datatables.delete')); ?>'
//   let deleteButton = {
//     text: deleteButtonTrans,
//     url: "<?php echo e(route('admin.prices.massDestroy')); ?>",
//     className: 'btn-danger',
//     action: function (e, dt, node, config) {
//       var ids = $.map(dt.rows({ selected: true }).nodes(), function (entry) {
//           return $(entry).data('entry-id')
//       });

//       if (ids.length === 0) {
//         alert('<?php echo e(trans('global.datatables.zero_selected')); ?>')

//         return
//       }

//       if (confirm('<?php echo e(trans('global.areYouSure')); ?>')) {
//         $.ajax({
//           headers: {'x-csrf-token': _token},
//           method: 'POST',
//           url: config.url,
//           data: { ids: ids, _method: 'DELETE' }})
//           .done(function () { location.reload() })
//       }
//     }
//   }
//   dtButtons.push(deleteButton)
// <?php endif; ?>

  $.extend(true, $.fn.dataTable.defaults, {
    orderCellsTop: true,
    order: [[ 1, 'desc' ]],
    pageLength: 100,
  });
  let table = $('.datatable-history_order_reservation:not(.ajaxTable)').DataTable({ buttons: dtButtons })
  $('a[data-toggle="tab"]').on('shown.bs.tab click', function(e){
      $($.fn.dataTable.tables(true)).DataTable()
          .columns.adjust();
  });
  
})

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/history_order_reservations/index.blade.php ENDPATH**/ ?>