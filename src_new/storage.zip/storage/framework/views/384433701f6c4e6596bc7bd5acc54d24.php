<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>Hans Restaurants</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href='https://unpkg.com/boxicons@2.1.2/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo e(asset('assets_makan/css/c.css')); ?>">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>

<body>
    <header>
        <div class="nav container">
            <a href="" class="logo"><span>HANS</span> Restaurants</a>
            <i class='bx bx-shopping-bag' id="cart-icon"></i>
            <div class="cart">
                <h2 class="cart-title">Your Cart</h2>
                <div class="cart-content">
                    <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="cart-box" data-product-id="<?php echo e($item['id']); ?>">
                        <img src="<?php echo e($item['img']); ?>" alt="" class="cart-img">
                        <div class="detail-box">
                            <div class="cart-product-title"><?php echo e($item['name']); ?></div>
                            <div class="cart-quantity-wrapper">
                                <button type="button" class="btn-quantity decrease" data-product-id="<?php echo e($item['id']); ?>" data-price="<?php echo e($item['price']); ?>">-</button>
                                <input type="number" value="<?php echo e($item['quantity']); ?>" class="cart-quantity" data-product-id="<?php echo e($item['id']); ?>" data-stock="<?php echo e($item['stock']); ?>" data-price="<?php echo e($item['price']); ?>">
                                <button type="button" class="btn-quantity increase" data-product-id="<?php echo e($item['id']); ?>" data-price="<?php echo e($item['price']); ?>">+</button>
                            </div>
                            <div class="cart-price" data-product-id="<?php echo e($item['id']); ?>">Rp<?php echo e(number_format($item['price'], 2, ',', '.')); ?></div>
                            <button type="button" class="btn-remove" data-product-id="<?php echo e($item['id']); ?>"><i class='bx bxs-trash-alt'></i></button>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="total">
                    <div class="total-title">Total</div>
                    <div class="total-price">Rp<?php echo e(number_format($total_price, 2, ',', '.')); ?></div>
                </div>
                
                <i class='bx bx-x' id="cart-close"></i>
            </div>
        </div>
    </header>

    <section class="shop container">
        <div class="input-group mb-3">
            <input type="text" class="form-control" placeholder="Search" aria-label="Search" aria-describedby="basic-addon1">
        </div>
        <h2 class="section-title" style="margin-bottom: -8%;">Shop Products</h2>
        <section id="menu" class="menu section-bg">
            <div class="container" data-aos="fade-up">
                <div class="section-title">
                    <h2>Menu</h2>
                    <p>Check Our Tasty Menu</p>
                </div>
            </div>
        </section>

        <div class="container" style="margin-top: -3%; width:50%;">
            <form id="orderForm" class="mb-5">
                <?php echo csrf_field(); ?>
                <div class="mb-3">
                    <label for="nama_pemesan" class="form-label">Name</label>
                    <input type="text" class="form-control" id="nama_pemesan" name="nama_pemesan" required>
                </div>
                <div class="mb-3">
                    <label for="table_id" class="form-label">Table</label>
                    <select class="form-control" id="table_id" name="table_id" required>
                        <?php $__currentLoopData = $tables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $table): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $disabled = $table->status == 'terbooking' ? 'disabled' : '';
                            ?>
                            <option value="<?php echo e($table->id); ?>" <?php echo e($disabled); ?>>
                                <?php echo e($table->name); ?> <?php echo e($table->status == 'terbooking' ? '(Terbooking)' : ''); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <button type="button" class="btn btn-primary" onclick="submitOrderForm()">Submit</button>
            </form>
        </div>

        <div class="shop-content">
            <div class="product-wrapper">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="product-box">
                        <img src="<?php echo e($product->getFirstMediaUrl('image', 'preview')); ?>" alt="<?php echo e($product->name); ?>" class="product-img">
                        <div class="product-details">
                            <h2 class="product-title"><?php echo e($product->name); ?></h2>
                            <span class="product-price">Rp<?php echo e(number_format($product->price, 2, ',', '.')); ?></span>
                            <span class="product-stock" data-stock="<?php echo e($product->stock); ?>">Stock: <?php echo e($product->stock); ?></span>
                            <form method="post" action="<?php echo e(route('makan.addToCart')); ?>" class="add-cart-form">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
                                <input type="hidden" name="product_name" value="<?php echo e($product->name); ?>">
                                <input type="hidden" name="product_price" value="<?php echo e($product->price); ?>">
                                <input type="hidden" name="product_img" value="<?php echo e($product->getFirstMediaUrl('image', 'preview')); ?>">
                                <button type="submit" class="btn-add-cart"><i class='bx bx-shopping-bag add-cart'></i></button>
                            </form>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>

    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
    <script src="<?php echo e(asset('assets_makan/js_makan/mainssss.js')); ?>"></script>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            fetch('/makan/get-cart', {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
                }
            })
            .then(response => response.json())
            .then(data => {
                const cartContent = document.querySelector('.cart-content');
                cartContent.innerHTML = ''; 
                data.cart.forEach(item => {
                    cartContent.innerHTML += `
                        <div class="cart-box" data-product-id="${item.id}">
                            <img src="${item.img}" alt="" class="cart-img">
                            <div class="detail-box">
                                <div class="cart-product-title">${item.name}</div>
                                <div class="cart-quantity-wrapper">
                                    <button type="button" class="btn-quantity decrease" data-product-id="${item.id}" data-price="${item.price}">-</button>
                                    <input type="number" value="${item.quantity}" class="cart-quantity" data-product-id="${item.id}" data-stock="${item.stock}" data-price="${item.price}">
                                    <button type="button" class="btn-quantity increase" data-product-id="${item.id}" data-price="${item.price}">+</button>
                                </div>
                                <div class="cart-price" data-product-id="${item.id}">Rp${item.price.toLocaleString('id-ID', { minimumFractionDigits: 2 })}</div>
                                <button type="button" class="btn-remove" data-product-id="${item.id}"><i class='bx bxs-trash-alt'></i></button>
                            </div>
                        </div>
                    `;
                });
                document.querySelector('.total-price').innerText = `Rp${data.total_price.toLocaleString('id-ID', { minimumFractionDigits: 2 })}`;
            })
            .catch(error => console.error('Error fetching cart:', error));
        
            document.querySelector('.cart-content').addEventListener('click', function(event) {
                const target = event.target;
                if (target.classList.contains('btn-remove') || target.closest('.btn-remove')) {
                    const productId = target.closest('.btn-remove').getAttribute('data-product-id');
                    removeFromCart(productId);
                }
            });
        
            document.querySelector('.cart-content').addEventListener('click', function(event) {
                const target = event.target;
                if (target.classList.contains('increase') || target.classList.contains('decrease')) {
                    const isIncrease = target.classList.contains('increase');
                    const input = target.closest('.cart-box').querySelector('.cart-quantity');
                    const productId = input.dataset.productId;
                    const stock = parseInt(input.dataset.stock);
                    const price = parseFloat(input.dataset.price);
                    let currentQuantity = parseInt(input.value);
        
                    if (isIncrease && currentQuantity < stock) {
                        currentQuantity++;
                    } else if (!isIncrease && currentQuantity > 1) {
                        currentQuantity--;
                    }
        
                    input.value = currentQuantity;
                    updateCart(productId, isIncrease ? 'increase' : 'decrease', currentQuantity, price);
                }
            });
        
            document.querySelectorAll('.add-cart-form').forEach(form => {
                form.addEventListener('submit', function(event) {
                    event.preventDefault();
                    const stock = parseInt(this.querySelector('.product-stock').dataset.stock);
                    if (stock > 0) {
                        this.submit();
                    } else {
                        Swal.fire({
                            icon: 'error',
                            title: 'Stock habis',
                            text: 'Produk ini tidak dapat ditambahkan ke keranjang karena stok habis.'
                        });
                    }
                });
            });
        });
        
        function removeFromCart(productId) {
            const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');
            fetch('<?php echo e(route('makan.removeFromCart')); ?>', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': csrfToken
                },
                body: JSON.stringify({ product_id: productId })
            })
            .then(response => response.json())
            .then(data => {
                if (data.cart) {
                    const cartBox = document.querySelector(`.cart-box[data-product-id="${productId}"]`);
                    if (cartBox) {
                        cartBox.remove();
                    }
                    document.querySelector('.total-price').innerText = `Rp${data.total_price.toLocaleString('id-ID', { minimumFractionDigits: 2 })}`;
                } else {
                    console.error('Error removing item from cart:', data);
                }
            })
            .catch(error => console.error('Error:', error));
        }
        
        function updateCart(productId, action, quantity, price) {
            const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');
            const updateCartUrl = '/makan/update-cart'; 
            const newTotalPrice = quantity * price;
            document.querySelector(`.cart-price[data-product-id="${productId}"]`).innerText = `Rp${newTotalPrice.toLocaleString('id-ID', { minimumFractionDigits: 2 })}`;
        
            let newGrandTotal = 0;
            document.querySelectorAll('.cart-quantity').forEach(input => {
                const productPrice = parseFloat(input.dataset.price);
                newGrandTotal += productPrice * parseInt(input.value);
            });
        
            document.querySelector('.total-price').innerText = `Rp${newGrandTotal.toLocaleString('id-ID', { minimumFractionDigits: 2 })}`;
        
            fetch(updateCartUrl, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': csrfToken
                },
                body: JSON.stringify({ product_id: productId, action: action, quantity: quantity })
            })
            .then(response => response.json())
            .then(data => {
                console.log('Update successful:', data);
            })
            .catch(error => console.error('Error updating cart:', error));
        }
        
        function searchFood() {
            let searchInput = document.querySelector('.form-control').value.toLowerCase();
            let productTitles = document.querySelectorAll('.product-title');
        
            productTitles.forEach(title => {
                let productName = title.textContent.toLowerCase();
                if (productName.includes(searchInput)) {
                    title.closest('.product-box').style.display = 'block';
                } else {
                    title.closest('.product-box').style.display = 'none';
                }
            });
        }
        
        let searchInput = document.querySelector('.form-control');
        searchInput.addEventListener('input', searchFood);
        
        function submitOrderForm() {
            const customerName = document.getElementById('nama_pemesan').value;
            const tableId = document.getElementById('table_id').value;
            const cartContent = document.querySelector('.cart-content');
            const products = [];
            let totalPrice = 0;
        
            cartContent.querySelectorAll('.cart-box').forEach(cartBox => {
                const productId = cartBox.getAttribute('data-product-id');
                const productQuantity = cartBox.querySelector('.cart-quantity').value;
                const productPrice = parseFloat(cartBox.querySelector('.cart-price').innerText.replace(/[^\d.-]/g, ''));
                totalPrice += productPrice * productQuantity;
                products.push({ id: parseInt(productId), qty: parseInt(productQuantity) });
            });
        
            const formData = new FormData();
            formData.append('nama_pemesan', customerName);
            formData.append('table_id', tableId);
            formData.append('product', JSON.stringify(products));
            formData.append('price', totalPrice);
            formData.append('_token', document.querySelector('meta[name="csrf-token"]').getAttribute('content'));
        
            fetch('<?php echo e(route('makan.saveOrder')); ?>', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                console.log('Success:', data);
                Swal.fire({
                    icon: 'success',
                    title: 'Order Berhasil',
                    text: 'Pesanan Anda telah berhasil disimpan.',
                    confirmButtonText: 'OK'
                }).then(() => {
                    document.getElementById('orderForm').reset();
                    fetch('/makan/get-cart', {
                        method: 'GET',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
                        }
                    })
                    .then(response => response.json())
                    .then(data => {
                        const cartContent = document.querySelector('.cart-content');
                        cartContent.innerHTML = ''; 
                        document.querySelector('.total-price').innerText = `Rp0,00`;
                    });
                });
            })
            .catch((error) => {
                console.error('Error:', error);
            });
        }
        </script>
        
</body>

</html>
<?php /**PATH /var/www/html/resources/views/layouts/makan_di_tempat/makan.blade.php ENDPATH**/ ?>