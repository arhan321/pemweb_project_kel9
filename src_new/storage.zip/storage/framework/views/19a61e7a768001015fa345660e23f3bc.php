<!-- ======= Footer ======= -->
<footer id="footer">
  <div class="footer-top">
    <div class="container">
      <div class="row">
        <?php if(!empty($footer)): ?>
          <?php $__currentLoopData = $footer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col-lg-3 col-md-6">
            <div class="footer-info">
              <?php if(isset($f->logo_restoran)): ?>
              <h3><?php echo $f->logo_restoran; ?></h3>
              <?php endif; ?>
              <?php if(isset($f->alamat)): ?>
              <p><?php echo $f->alamat; ?></p>
              <?php endif; ?>
            </div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         <?php else: ?>
          <div class="col-lg-12">
            <p>No footer data available.</p>
          </div>
          <?php endif; ?>
            <div class="col-lg-2 col-md-6 footer-links">
              <h4><?php echo e(trans('panel.frontend.Footer.usefullinks')); ?></h4>
              <ul>
                <li>
                  <i class="bx bx-chevron-right"></i> <a href="<?php echo e(route('frontend.home')); ?>"><?php echo e(trans('panel.frontend.usefullinks.Home')); ?></a>
                </li>
                <li>
                  <i class="bx bx-chevron-right"></i>
                  <a href="<?php echo e(route('frontend.about')); ?>"><?php echo e(trans('panel.frontend.usefullinks.Abouts')); ?></a>
                </li>
                <li>
                  <i class="bx bx-chevron-right"></i> <a href="<?php echo e(route('frontend.menu')); ?>"><?php echo e(trans('panel.frontend.usefullinks.Menu')); ?></a>
                </li>
                <li>
                  <i class="bx bx-chevron-right"></i>
                  <a href="<?php echo e(route('frontend.signature')); ?>"><?php echo e(trans('panel.frontend.usefullinks.Signature')); ?></a>
                </li>
                
                <li>
                  <i class="bx bx-chevron-right"></i>
                  <a href="<?php echo e(route('frontend.galery')); ?>"><?php echo e(trans('panel.frontend.usefullinks.Galery')); ?></a>
                </li>
                
                <li>
                  <i class="bx bx-chevron-right"></i>
                  <a href="https://wa.me/6282113862854"><?php echo e(trans('panel.frontend.usefullinks.Contact')); ?></a>
                </li>
              </ul>
            </div>
            <?php if(!empty($footer)): ?>
            <?php $__currentLoopData = $footer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-3 col-md-6 footer-links">
                <?php if(isset($fo->opening_day) || isset($fo->opening_hours) || isset($fo->closing_hours)): ?>
                <h4><?php echo e(trans('panel.frontend.Footer.openinghours')); ?></h4>
                <ul>
                    <?php if(isset($fo->opening_day)): ?>
                    <li><?php echo $fo->opening_day; ?></li>
                    <?php endif; ?>
                    <?php if(isset($fo->opening_hours) && isset($fo->closing_hours)): ?>
                    <li><?php echo $fo->opening_hours; ?> - <?php echo $fo->closing_hours; ?></li>
                    <?php endif; ?>
                </ul>
                <?php endif; ?>
            </div>
         
            <div class="col-lg-4 col-md-6 footer-newsletter">
              <h4><?php echo e(trans('panel.frontend.Footer.contact')); ?></h4>
              <p>
                <strong><?php echo e(trans('panel.frontend.Footer.phone')); ?></strong> <?php echo $fo->phone; ?><br />
                  <strong><?php echo e(trans('panel.frontend.Footer.email')); ?></strong> <?php echo $fo->email; ?><br />
              </p>
              <!-- <form action="" method="post">
                <input type="email" name="email" /><input
                  type="submit"
                  value="Subscribe"
                />
              </form> -->
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
              <div class="col-lg-12">
                <p>No data available.</p>
              </div>
            <?php endif; ?>
          </div>
        </div>
      </div>
      <?php $__currentLoopData = $footer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="container">
        <div class="copyright">
          &copy; <?php echo e(trans('panel.frontend.Footer.copyright')); ?> <strong><span><?php echo $fot->copyright; ?></span></strong
          >. All Rights Reserved
        </div>
        <div class="credits">
          <!-- All the links in the footer should remain intact. -->
          <!-- You can delete the links only if you purchased the pro version. -->
          <!-- Licensing information: https://bootstrapmade.com/license/ -->
          <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/restaurantly-restaurant-template/ -->
          <?php echo e(trans('panel.frontend.Footer.desain_by')); ?> <a href="https://bootstrapmade.com/"><?php echo $fot->desain_by; ?></a>
        </div>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php if($footer->isEmpty()): ?>
      <div class="container">
        <div class="col-lg-12">
          <p>No footer data available.</p>
        </div>
      </div>
      <?php endif; ?>
    </footer>
    <!-- End Footer -->
    <div id="preloader"></div>
    <a
      href="#"
      class="back-to-top d-flex align-items-center justify-content-center"
      ><i class="bi bi-arrow-up-short"></i
    ></a>
<?php /**PATH /var/www/html/resources/views/layouts/inc/footers.blade.php ENDPATH**/ ?>