<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header">
                    Dashboard
                </div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                
                    <div class="user-info">
                        <p>You are logged in as:</p>
                        <div class="user-name"><?php echo e(Auth::user()->name); ?></div>
                        <div class="user-roles">
                            Roles:
                            <?php $__currentLoopData = Auth::user()->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span class="role"><?php echo e($role->title); ?></span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row mb-4">
    <div class="col-lg-6 mb-4">
        <div class="card p-4 shadow-sm">
            <div class="card-body">
                <?php echo $chart->container(); ?>

            </div>
        </div>
    </div>
    <div class="col-lg-6 mb-4">
        <div class="card p-4 shadow-sm">
            <div class="card-body">
                <?php echo $chartArea->container(); ?>

            </div>
        </div>
    </div>
</div>

<div class="row mb-4">
    <div class="col-lg-12">
        <div class="card p-4 shadow-sm">
            <div class="card-body">
                <?php echo $penghasilanbulanini->container(); ?>

            </div>
        </div>
    </div>
</div>
<div class="row mb-4">
    <div class="col-lg-12">
        <div class="card p-4 shadow-sm">
            <div class="card-body">
                <?php echo $chartByDineIn->container(); ?>

            </div>
        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e($chart->cdn()); ?>"></script>
<?php echo e($chart->script()); ?>


<script src="<?php echo e($chartArea->cdn()); ?>"></script>
<?php echo e($chartArea->script()); ?>


<script src="<?php echo e($penghasilanbulanini->cdn()); ?>"></script>
<?php echo e($penghasilanbulanini->script()); ?>


<script src="<?php echo e($chartByDineIn->cdn()); ?>"></script>
<?php echo e($chartByDineIn->script()); ?>

<?php echo \Illuminate\View\Factory::parentPlaceholder('scripts'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/home.blade.php ENDPATH**/ ?>