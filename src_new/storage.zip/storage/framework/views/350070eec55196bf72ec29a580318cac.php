<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Restaurant Reservation</title>
    <meta name="description" content="Reserve your table at our restaurant easily and quickly. Choose your preferred day and time, and provide your contact details.">
    <link rel="stylesheet" href="frontend/reservasi/stylee.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<body>
    <section class="banner">
        <img src="frontend/assets/img/about.jpg" alt="Background Image" class="bg-img">
        <div class="overlay">
            <h2>BOOK YOUR TABLE NOW</h2>
            <div class="card-container">
                <div class="card-content">
                    <h1>Reservation</h1>
                    <?php if(session('success')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php endif; ?>

                    <?php if(session('error')): ?>
                        <div class="alert alert-danger">
                            <?php echo e(session('error')); ?>

                        </div>
                    <?php endif; ?>

                    <form id="reservationForm" action="<?php echo e(route('midtrans.checkout')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="form-row">
                            <div class="form-row">
                                <label for="days">Select Date</label>
                                <input type="date" name="days" id="date" class="form-control" required>
                            </div>
                            <div class="form-row">
                                <select name="table_id" id="table_id" class="form-control" required>
                                    <option value="">Select Table</option>
                                    <?php $__currentLoopData = $availableTables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $table): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $start = new \DateTime($table->start);
                                            $end = new \DateTime($table->finish);
                                            $range = $start->format('H:i') . ' - ' . $end->format('H:i');
                                        ?>
                                        <option value="<?php echo e($table->id); ?>">Table <?php echo e($table->name); ?> (<?php echo e($range); ?>)</option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-row">
                            <input type="text" name="name" placeholder="Full Name" class="form-control" required>
                            <input type="tel" name="phone" placeholder="Phone Number" class="form-control" required>
                            <input type="email" name="customer_email" placeholder="Email" class="form-control" required>
                            <input type="number" name="qty" placeholder="Number of people" min="1" max="8" class="form-control" required>
                        </div>
                        <div class="d-grid gap-2">
                            <button class="btn btn-primary" type="submit">Reserve Now</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>
    <script>
        // var currentTime = new Date();
        // var currentHour = currentTime.getHours();

        // if (currentHour >= 22 || currentHour < 08) {
        //     window.location.href = '/error';
        // }
        document.getElementById('reservationForm').addEventListener('submit', function(event) {
            event.preventDefault();
            var form = this;
            form.submit();
        });
    //     if (currentHour >= 22 || currentHour < 08) {
    //             window.location.href = '/error';
    //         } else {
    //             form.submit();
    //         }
    // </script>
    
</body>
</html><?php /**PATH /var/www/html/resources/views/layouts/reservasi.blade.php ENDPATH**/ ?>