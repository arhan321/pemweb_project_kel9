<?php $__env->startSection('section'); ?>

<!-- ======= Hero Section ======= -->
<?php $__empty_1 = true; $__currentLoopData = $Home; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $H): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
<section id="hero" class="d-flex align-items-center">
    <div class="background-image">
        <?php if($H->getFirstMediaUrl('image', 'priview')): ?>
            <img src="<?php echo e($H->getFirstMediaUrl('image', 'priview')); ?>" alt="<?php echo e($H->title); ?>" />
        <?php else: ?>
            <p><?php echo e(trans('panel.frontend.img.error')); ?></p>
        <?php endif; ?>
    </div>
    <div class="container position-relative text-center text-lg-start" data-aos="zoom-in" data-aos-delay="100">
        <div class="row">
            <div class="col-lg-8">
                <?php if(isset($H->title)): ?>
                    <h1><?php echo e($H->title); ?></h1>
                <?php else: ?>
                    <h1><?php echo e(trans('panel.frontend.error.title')); ?></h1>
                <?php endif; ?>
                <!-- <h2>Delivering great food for more than 18 years!</h2> -->
                <!-- <div class="btns">
                    <a href="https://wa.me/6282113862854" class="btn-menu animated fadeInUp scrollto">Ask me</a>
                    <a href="reservasi.html" class="btn-book animated fadeInUp scrollto">Book a Table</a>
                </div> -->
            </div>
        </div>
    </div>
</section>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
<section id="hero" class="d-flex align-items-center">
    <div class="container position-relative text-center text-lg-start" data-aos="zoom-in" data-aos-delay="100">
        <div class="row">
            <div class="col-lg-8">
                <h1>Error: No hero section available</h1>
            </div>
        </div>
    </div>
</section>
<?php endif; ?>
<!-- End Hero -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/frontend/home.blade.php ENDPATH**/ ?>