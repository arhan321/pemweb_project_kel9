<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <?php echo e(trans('global.create')); ?> <?php echo e(trans('cruds.orderditempat.title_singular')); ?>

        </div>

        <div class="card-body">
            <form method="POST" action="<?php echo e(route('admin.orderditempats.store')); ?>">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="nama_pemesan"><?php echo e(trans('cruds.orderditempat.fields.nama_pemesan')); ?></label>
                    <input class="form-control <?php echo e($errors->has('nama_pemesan') ? 'is-invalid' : ''); ?>" type="text"
                        name="nama_pemesan" id="nama_pemesan" value="<?php echo e(old('nama_pemesan', '')); ?>">
                    <?php if($errors->has('nama_pemesan')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('nama_pemesan')); ?>

                        </div>
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <label for="products"><?php echo e(trans('cruds.orderditempat.fields.product')); ?></label>
                    <select class="form-control select2 <?php echo e($errors->has('products') ? 'is-invalid' : ''); ?>"
                        name="products[]" id="products" multiple>
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($id); ?>"
                                <?php echo e(in_array($id, old('products', [])) ? 'selected' : ''); ?>><?php echo e($product); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php if($errors->has('products')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('products')); ?>

                        </div>
                    <?php endif; ?>
                </div>

                <div id="product-quantities">
                    <!-- Placeholder for dynamic product quantities -->
                </div>
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
                
                <div class="form-group">
                    <label for="price"><?php echo e(trans('cruds.orderditempat.fields.price')); ?></label>
                    <input class="form-control <?php echo e($errors->has('price') ? 'is-invalid' : ''); ?>" type="number"
                        name="price" id="price" value="<?php echo e(old('price', '')); ?>" readonly>
                    <?php if($errors->has('price')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('price')); ?>

                        </div>
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <label for="jam_pesan"><?php echo e(trans('cruds.orderditempat.fields.jam_pesan')); ?></label>
                    <input class="form-control <?php echo e($errors->has('jam_pesan') ? 'is-invalid' : ''); ?>" type="time"
                        name="jam_pesan" id="jam_pesan" value="<?php echo e(old('jam_pesan', '')); ?>">
                    <?php if($errors->has('jam_pesan')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('jam_pesan')); ?>

                        </div>
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <label for="tanggal_pesan"><?php echo e(trans('cruds.orderditempat.fields.tanggal_pesan')); ?></label>
                    <input class="form-control <?php echo e($errors->has('tanggal_pesan') ? 'is-invalid' : ''); ?>" type="date"
                        name="tanggal_pesan" id="tanggal_pesan" value="<?php echo e(old('tanggal_pesan', '')); ?>">
                    <?php if($errors->has('tanggal_pesan')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('tanggal_pesan')); ?>

                        </div>
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <label for="table"><?php echo e(trans('cruds.orderditempat.fields.table')); ?></label>
                    <select class="form-control <?php echo e($errors->has('table') ? 'is-invalid' : ''); ?>" name="table_id"
                        id="table">
                        <?php $__currentLoopData = $tables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $table): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($table->id); ?>" <?php echo e(old('table_id') == $table->id ? 'selected' : ''); ?>

                                <?php echo e($table->status == 'terbooking' ? 'disabled' : ''); ?>>
                                <?php echo e($table->name); ?> - <?php echo e($table->status); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php if($errors->has('table')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('table')); ?>

                        </div>
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <label class="required"><?php echo e(trans('cruds.orderditempat.fields.status_bayar')); ?></label>
                    <select class="form-control <?php echo e($errors->has('status_bayar') ? 'is-invalid' : ''); ?>" name="status_bayar"
                        id="status_bayar" required>
                        <option value disabled <?php echo e(old('status_bayar', null) === null ? 'selected' : ''); ?>>
                            <?php echo e(trans('global.pleaseSelect')); ?></option>
                        <?php $__currentLoopData = App\Models\Orderditempat::STATUS_SELECT; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($key); ?>"
                                <?php echo e(old('status_bayar', '') === (string) $key ? 'selected' : ''); ?>><?php echo e($label); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php if($errors->has('status_bayar')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('status_bayar')); ?>

                        </div>
                    <?php endif; ?>
                    <span class="help-block"><?php echo e(trans('cruds.orderditempat.fields.status_bayar_helper')); ?></span>
                </div>

                <div class="form-group">
                    <button class="btn btn-danger" type="submit">
                        <?php echo e(trans('global.save')); ?>

                    </button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('scripts'); ?>
    <script>
        $(document).ready(function() {
            const productPrices = <?php echo json_encode($productPrices, 15, 512) ?>;

            function updateProductQuantities() {
                let selectedProducts = $('#products').val();
                let productQuantitiesContainer = $('#product-quantities');
                productQuantitiesContainer.empty();

                selectedProducts.forEach(function(productId, index) {
                    let productLabel = $('#products option[value="' + productId + '"]').text();
                    let productPrice = productPrices[productId];
                    productQuantitiesContainer.append(`
                    <div class="form-group">
                        <label for="qty_${productId}">${productLabel} <?php echo e(trans('cruds.orderditempat.fields.qty')); ?></label>
                        <input class="form-control product-qty" data-product-id="${productId}" type="number" name="product_qty[${productId}]" id="qty_${productId}" value="1">
                        <input type="hidden" class="product-price" data-product-id="${productId}" value="${productPrice}">
                    </div>
                `);
                });

                updateTotalPrice();
            }

            function updateTotalPrice() {
                let totalPrice = 0;
                $('.product-qty').each(function() {
                    let productId = $(this).data('product-id');
                    let quantity = parseFloat($(this).val());
                    let price = parseFloat($('.product-price[data-product-id="' + productId + '"]').val());
                    totalPrice += quantity * price;
                });
                $('#price').val(totalPrice.toFixed(2));
            }

            $('#products').change(function() {
                updateProductQuantities();
            });

            $('#product-quantities').on('input', '.product-qty', function() {
                updateTotalPrice();
            });

            updateProductQuantities();
        });

        $(function() {
            let dtButtons = $.extend(true, [], $.fn.dataTable.defaults.buttons)
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('orderditempat_delete')): ?>
                let deleteButtonTrans = '<?php echo e(trans('global.datatables.delete')); ?>'
                let deleteButton = {
                    text: deleteButtonTrans,
                    url: "<?php echo e(route('admin.orderditempats.massDestroy')); ?>",
                    className: 'btn-danger',
                    action: function(e, dt, node, config) {
                        var ids = $.map(dt.rows({
                            selected: true
                        }).nodes(), function(entry) {
                            return $(entry).data('entry-id')
                        });

                        if (ids.length === 0) {
                            alert('<?php echo e(trans('global.datatables.zero_selected')); ?>')

                            return
                        }

                        if (confirm('<?php echo e(trans('global.areYouSure')); ?>')) {
                            $.ajax({
                                    headers: {
                                        'x-csrf-token': _token
                                    },
                                    method: 'POST',
                                    url: config.url,
                                    data: {
                                        ids: ids,
                                        _method: 'DELETE'
                                    }
                                })
                                .done(function() {
                                    location.reload()
                                })
                        }
                    }
                }
                dtButtons.push(deleteButton)
            <?php endif; ?>

            $.extend(true, $.fn.dataTable.defaults, {
                orderCellsTop: true,
                order: [
                    [1, 'desc']
                ],
                pageLength: 100,
            });
            let table = $('.datatable-orderditempat:not(.ajaxTable)').DataTable({
                buttons: dtButtons
            })
            $('a[data-toggle="tab"]').on('shown.bs.tab click', function(e) {
                $($.fn.dataTable.tables(true)).DataTable()
                    .columns.adjust();
            });
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/orderditempats/create.blade.php ENDPATH**/ ?>